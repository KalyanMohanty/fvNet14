def add_num(a, b):
    print('Sum = ', a+b)

if __name__ == '__main__':
    add_num()